

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import testApp.ChatUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UserValidate
 */
@WebServlet(name = "UserValidation", urlPatterns = { "/UserValidation" })
public class UserValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserValidate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at User Validate: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("In validation");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		
		//Getting all users in the group chat
		HashMap<String,String>  usersList=ChatUtil.getUserList();
		
		//Authenticating the user
			if(!usersList.isEmpty()&&usersList.containsKey(request.getParameter("uname"))){
				String pwd=usersList.get(request.getParameter("uname"));
				if(pwd.matches(request.getParameter("upwd"))){
					out.println("User Validated successfully"+request.getParameter("uname"));
					session.setAttribute("LoggedInUser", request.getParameter("uname"));
					//Upon matching send the user to Chat Room
					response.sendRedirect("index.jsp"); 
				}
				else{
					out.println("Invalid user name or password");
				}
			}else if(request.getParameter("uname")!=null&&request.getParameter("uname")!=""&&request.getParameter("upwd")!=null&&request.getParameter("upwd")!=""){
				ChatUtil.addUser(request.getParameter("uname"),request.getParameter("upwd"));
				//Adding new user to chat room
				session.setAttribute("LoggedInUser", request.getParameter("uname"));
				response.sendRedirect("index.jsp");
			}else{
				out.println("Invalid user name or password");
			}
		
	}

}
