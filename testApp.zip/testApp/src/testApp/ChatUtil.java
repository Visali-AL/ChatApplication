//$Id$
package testApp;


import java.util.ArrayList;
import java.util.HashMap;

public class ChatUtil {

	//vlist that holds messages
	public static ArrayList<String> msgs=new ArrayList<String>();
	public static HashMap<String,String> userDetails=new HashMap<>();
	public ChatUtil(){
		System.out.println("Object created");
	}
	public ArrayList<String> getMessagesList(){
		return msgs;
		
	}
	public void addMessage(String message,String user){  
		//adding the user data and message to list
		msgs.add(java.time.LocalDate.now()+" "+java.time.LocalTime.now()+" "+user+" "+message);
		System.out.println(msgs);
		
	}
	public static void addUser(String uname, String pwd){
		//adding valid user to list
		userDetails.put(uname, pwd);
	}
	
	public static HashMap<String,String> getUserList(){
		//getting all valid users
		return userDetails;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
